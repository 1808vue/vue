<template>
    <div class="nav_menu">
       <ul>
       	<li 
       	v-for='(item,index) in navlist' 
       	:key='index'
       	@click='toggle(item.path,item.tag)'
       	:class='sel===item.tag?"you":""'
       	>{{item.name}}					
       	</li>
       	
       </ul>
     </div>
    
   
    
</template>
<script>

export default{
   name:"food",
   data(){
    return{
      datas:"母婴之家",
      navlist:[{name:'首页',path:'/home',tag:'nav1'},{name:'分类',path:'/List',tag:'nav2'},{name:'购物车',path:'/car',tag:'nav3'},{name:'我的',path:'/my',tag:'nav4'}],
      list:'/home',
		  sel:'nav1'

   }
	 },
  methods:{
   toggle(path,val){
		 window.sessionStorage.setItem('sel',val);
			this.sel=val
   		this.$router.push(path);
   	},
   	
   },
		
	created(){
		let sel = Number(sessionStorage.getItem('sel'));
		this.sel=sel;

	}
   }
   
  
</script>
<style lang="less" scoped>
	@import url("../../../styls/main.less");
.nav_menu{
  position:fixed;
  z-index: 999;
  background: #fff;
  bottom: 0;
  width:100%;
  left:0;
  ul{
    display:flex;
    justify-content: space-around;
    li{
      display:flex;
      flex-direction: column;
      .fs(14);
      color: #82737A;
    }

  }
}
  .you {
      color: #E95535;
    }
</style>
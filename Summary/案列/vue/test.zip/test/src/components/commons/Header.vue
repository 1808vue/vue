<template>
    <div class='headers'>
   
    </div>

</template>

<script>

export default{
   name:"top",
   data(){
    return{
        
    }
   },
     methods: {
     
      }
    }
   

</script>

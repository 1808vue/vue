<template>
     <div class='tab' style="position:relative;">
    	
      </div>
</template>
<script>
export default{
   name:"lists",
	data(){
		return{
		
		}
	},
	methods:{
		
		},
		
   } 
</script>
<style>
	
	
</style>
<template>
	<div>
	<Lists></Lists>
	
	</div>
</template>
<script>
	import Lists from './Lists.vue'
	export default {
		name: "lists",
		components: {
			Lists
		},
		data(){
			return{
				list:"列表项"
			}
		}
	
	}
</script>

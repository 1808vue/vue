<template>
    <div class='home'>
     <Mys></Mys>
    </div>

</template>
<script>
import Mys from "./Mys.vue"
export default{
   name:"my",
	 components:{
		Mys
	 },
   data(){
    return{

    }
   }
  
}   

</script>

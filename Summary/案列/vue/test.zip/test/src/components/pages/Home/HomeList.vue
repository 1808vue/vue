<template>
    <div class='homeList'>
      首页
    </div>

</template>

<script>

export default{
  name:"list",
  data(){
  return{
   
  }
  }
  } 
</script>

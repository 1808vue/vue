<template>
    <div class='car'>
    
    </div>

</template>
<script>

export default{
   name:"my",
	 components:{
		
	 },
   data(){
    return{

    }
   }
  
}   

</script>
